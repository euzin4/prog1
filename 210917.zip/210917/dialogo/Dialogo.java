import javax.swing.JOptionPane;

public class Dialogo{
	public static void main(String[]args){
		JOptionPane.showMessageDialog(null,"É Java\nMano!");
	}
}