public class Principal{
	public static void main(String[] args) {
		Conta continha = new Conta(1,6000);
		Conta contao = new Conta(3,700);

		System.out.println(contao.quantidadeDeContas);
	}
}