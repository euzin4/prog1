package aula;

public class Pessoa {
    int idade;
    float peso;
    String nome;    //terminar
}
