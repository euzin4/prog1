public class Pessoa{
	String nomeAutor;
	String emailAutor;
	String cpfAutor;

	public void mostraDetalhes1(){
			System.out.println("\nDetalhes");
			System.out.println("Nome: "+this.nomeAutor);
			System.out.println("Email: "+this.emailAutor);
			System.out.println("CPF: "+this.cpfAutor+"\n");
	}
}