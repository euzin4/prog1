public class Teste{
	public static void main(String[] args){
		Livro livrinho = new Livro();
		livrinho.nome = "nome do livro";

		livrinho.autor.nome="nome do autor";
		livrinho.valor=123;
		livrinho.descricao="descricao aqui";
		livrinho.isbn="123123123";
	}
}
