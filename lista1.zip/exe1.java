class exe1{
	public static void main(String[] args){
		int i;
		for(i=120;i<281;i++){
			System.out.println(i);
		}
	}
}