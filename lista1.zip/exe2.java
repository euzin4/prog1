class exe2{
	public static void main(String[] args){
		int i,val=0;
		for(i=1;i<=500;i++){
			val+=i;
		}
		System.out.println(val);
	}	
}
