class exe3{
	public static void main(String[]args){
		int i;
		for(i=50;i<151;i++){
			if(i%3==0){
				System.out.println(i);
			}
		}
	}
}