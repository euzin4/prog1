package com.example.aluno_uffs.aula2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class Aula2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aula2);

        final Button botao = findViewById(R.id.id_do_botao);
        final ListView minha_lista = findViewById(R.id.id_da_lista);
        final EditText meu_editor = findViewById(R.id.id_cdt);

        Spellbook.getInstance().spells.add(
                new Spell("Avada Kedavra",false)
                );
        Spellbook.getInstance().spells.add(
                new Spell("Fireball", false)
        );

        final SpellbookAdapter adaptador = new SpellbookAdapter(this);
        minha_lista.setAdapter(adaptador);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String texto = meu_editor.getText().toString();
                Spellbook.getInstance().spells.add(
                        new Spell(texto,false)
                );
                adaptador.notifyDataSetChanged();
            }
        });


    }
}
